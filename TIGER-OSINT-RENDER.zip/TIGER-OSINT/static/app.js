const form = document.getElementById("scan-form");
const message = document.getElementById("message");
const button = document.getElementById("scan-btn");
const results = document.getElementById("results");
const exportButton = document.getElementById("export-btn");
let lastResult = null;

function setText(id, value) {
  document.getElementById(id).textContent =
    value === null || value === undefined || value === "" ? "—" : value;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  results.classList.add("hidden");
  message.textContent = "";
  button.disabled = true;
  button.textContent = "ANALYSE...";
  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({domain: document.getElementById("domain").value})
    });
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error(payload.error || "Analyse impossible.");
    lastResult = payload.result;
    renderResults(lastResult);
    message.textContent = "Analyse terminée.";
  } catch (error) {
    message.textContent = error.message;
  } finally {
    button.disabled = false;
    button.innerHTML = 'ANALYSER <span>↗</span>';
  }
});

function renderResults(data) {
  const sec = data.security;
  setText("r-domain", data.domain);
  setText("r-count", data.address_count);
  setText("r-https", sec.https_available ? "AVAILABLE" : "NO / UNKNOWN");
  setText("r-tls", sec.tls_version);
  setText("r-expiry", sec.certificate_expiry);
  setText("r-days", sec.certificate_days_remaining);
  setText("r-http", sec.http_status);
  const addresses = document.getElementById("r-addresses");
  addresses.replaceChildren();
  data.addresses.forEach(address => {
    const li = document.createElement("li");
    li.textContent = address;
    addresses.appendChild(li);
  });
  const headers = document.getElementById("r-headers");
  headers.replaceChildren();
  Object.entries(sec.security_headers || {}).forEach(([name, info]) => {
    const item = document.createElement("div");
    item.className = "header-item";
    const label = document.createElement("span");
    label.textContent = name;
    const state = document.createElement("b");
    state.className = info.present ? "present" : "missing";
    state.textContent = info.present ? "PRESENT" : "MISSING";
    item.append(label, state);
    headers.appendChild(item);
  });
  const errors = document.getElementById("r-errors");
  errors.textContent = (sec.errors || []).join(" ");
  results.classList.remove("hidden");
  results.scrollIntoView({behavior:"smooth", block:"start"});
}

exportButton.addEventListener("click", async () => {
  if (!lastResult) return;
  exportButton.disabled = true;
  try {
    const response = await fetch("/api/report", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({result:lastResult})
    });
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error(payload.error || "Export impossible.");
    window.location.href = payload.download;
  } catch (error) {
    message.textContent = error.message;
  } finally {
    exportButton.disabled = false;
  }
});
