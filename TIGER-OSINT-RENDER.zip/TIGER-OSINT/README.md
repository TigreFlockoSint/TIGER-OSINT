# TIGER OSINT — Public Domain Analyzer

Interface web Python/Flask pour une analyse passive et limitée de domaines publics.

## Fonctions
- Validation et normalisation d'un nom de domaine
- Résolution DNS IPv4/IPv6
- Vérification HTTPS et certificat TLS
- Vérification de six en-têtes HTTP de sécurité
- Export JSON horodaté

## Installation
Python 3.11+ recommandé.

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Ouvrir ensuite http://127.0.0.1:5000

## Limites et sécurité
- Utiliser uniquement sur des domaines publics que vous possédez ou êtes autorisé à auditer.
- Le programme bloque les domaines qui résolvent vers des adresses IP non publiques.
- Les connexions TLS sont épinglées à l'adresse IP publique validée et conservent le SNI du domaine.
- Aucun scan de ports, contournement d'accès, collecte de données personnelles ou suivi de personnes.
- L'analyse HTTP utilise HEAD sur `/` et ne suit pas les redirections.
- Un en-tête manquant n'est pas à lui seul la preuve d'une vulnérabilité.
- Pour une mise en production, utiliser un serveur WSGI, HTTPS, des limites de débit et une authentification adaptée.

## Lancement local
Le serveur intégré de Flask est destiné au développement local, pas à une exposition publique sur Internet.


## Déploiement Render
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- Runtime: Python 3
- Plan: Free (si disponible dans votre région/compte)

L'application écoute sur `0.0.0.0` et utilise la variable d'environnement `PORT`.
