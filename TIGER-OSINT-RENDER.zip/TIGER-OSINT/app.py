import ipaddress
import json
import os
import re
import socket
import ssl
import http.client
from datetime import datetime, timezone
from urllib.parse import urlparse

from flask import Flask, render_template, request, jsonify, send_from_directory

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024
REPORT_DIR = os.path.join(os.path.dirname(__file__), "reports")
TIMEOUT = 8
USER_AGENT = "TigerOSINT/1.0 (Public Domain Security Audit)"

SECURITY_HEADERS = {
    "strict-transport-security": "HTTPS enforcement",
    "content-security-policy": "Content injection protection",
    "x-content-type-options": "MIME sniffing protection",
    "x-frame-options": "Clickjacking protection",
    "referrer-policy": "Referrer information control",
    "permissions-policy": "Browser permissions control",
}

def normalize_domain(value):
    value = (value or "").strip().lower()
    if not value:
        raise ValueError("Entre un nom de domaine.")
    if "://" in value:
        parsed = urlparse(value)
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            raise ValueError("URL invalide.")
        if parsed.username or parsed.password or parsed.port not in (None, 80, 443):
            raise ValueError("Les identifiants et ports personnalisés ne sont pas acceptés.")
        value = parsed.hostname
    value = value.rstrip(".")
    if any(ch in value for ch in ("/", "\\", "@", ":", "#", "?")):
        raise ValueError("Format de domaine invalide.")
    try:
        value = value.encode("idna").decode("ascii")
    except UnicodeError:
        raise ValueError("Nom de domaine international invalide.")
    if len(value) > 253:
        raise ValueError("Nom de domaine trop long.")
    labels = value.split(".")
    if len(labels) < 2:
        raise ValueError("Entre un domaine complet, par exemple example.com.")
    for label in labels:
        if not label or len(label) > 63 or not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", label):
            raise ValueError("Nom de domaine invalide.")
    return value

def resolve_public_domain(domain):
    try:
        infos = socket.getaddrinfo(domain, None, type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise ValueError("Le domaine ne se résout pas en DNS.")
    addresses = sorted({item[4][0] for item in infos})
    if not addresses:
        raise ValueError("Aucune adresse DNS trouvée.")
    parsed = [ipaddress.ip_address(addr) for addr in addresses]
    if any(not ip.is_global for ip in parsed):
        raise ValueError("Analyse bloquée : le domaine renvoie vers une adresse non publique.")
    return addresses

def tls_and_headers(domain, pinned_ip):
    result = {
        "https_available": False, "tls_version": None,
        "certificate_expiry": None, "certificate_days_remaining": None,
        "http_status": None, "security_headers": {}, "errors": []
    }
    context = ssl.create_default_context()
    raw = None
    try:
        # Connect to the already-validated public IP while preserving domain SNI
        raw = socket.create_connection((pinned_ip, 443), timeout=TIMEOUT)
        with context.wrap_socket(raw, server_hostname=domain) as tls:
            result["https_available"] = True
            result["tls_version"] = tls.version()
            cert = tls.getpeercert()
            expiry = cert.get("notAfter")
            if expiry:
                expiry_dt = datetime.strptime(expiry, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                result["certificate_expiry"] = expiry_dt.isoformat()
                result["certificate_days_remaining"] = (expiry_dt - datetime.now(timezone.utc)).days

        # Fetch headers over a second pinned TLS connection; no redirects followed.
        raw2 = socket.create_connection((pinned_ip, 443), timeout=TIMEOUT)
        with context.wrap_socket(raw2, server_hostname=domain) as tls2:
            request_bytes = (
                f"HEAD / HTTP/1.1\r\nHost: {domain}\r\n"
                f"User-Agent: {USER_AGENT}\r\nConnection: close\r\n\r\n"
            ).encode("ascii")
            tls2.sendall(request_bytes)
            response = tls2.recv(16384).decode("iso-8859-1", errors="replace")
            first_line = response.split("\r\n", 1)[0]
            match = re.match(r"HTTP/\d(?:\.\d)?\s+(\d{3})", first_line)
            if match:
                result["http_status"] = int(match.group(1))
            headers = {}
            for line in response.split("\r\n")[1:]:
                if not line:
                    break
                if ":" in line:
                    key, val = line.split(":", 1)
                    headers[key.strip().lower()] = val.strip()
            for key, description in SECURITY_HEADERS.items():
                result["security_headers"][key] = {
                    "description": description,
                    "present": key in headers,
                    "value": headers.get(key)
                }
    except ssl.SSLCertVerificationError:
        result["errors"].append("Le certificat TLS n'a pas pu être vérifié.")
    except (ssl.SSLError, OSError, TimeoutError) as exc:
        result["errors"].append(f"Connexion HTTPS impossible : {type(exc).__name__}.")
    return result

def analyze(domain_input):
    domain = normalize_domain(domain_input)
    addresses = resolve_public_domain(domain)
    security = tls_and_headers(domain, addresses[0])
    return {
        "domain": domain,
        "addresses": addresses,
        "address_count": len(addresses),
        "dns_status": "SUCCESS",
        "security": security,
        "scope": "Analyse passive et limitée du domaine public fourni."
    }

@app.get("/")
def index():
    return render_template("index.html")

@app.post("/api/analyze")
def api_analyze():
    data = request.get_json(silent=True) or {}
    try:
        result = analyze(data.get("domain", ""))
        return jsonify({"ok": True, "result": result})
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except Exception:
        app.logger.exception("Unexpected analysis error")
        return jsonify({"ok": False, "error": "Erreur interne pendant l'analyse."}), 500

@app.post("/api/report")
def api_report():
    data = request.get_json(silent=True) or {}
    result = data.get("result")
    if not isinstance(result, dict) or not isinstance(result.get("domain"), str):
        return jsonify({"ok": False, "error": "Rapport invalide."}), 400
    os.makedirs(REPORT_DIR, exist_ok=True)
    stamp = datetime.now(timezone.utc)
    report = {
        "application": "TIGER OSINT",
        "version": "1.0.0",
        "generated_at": stamp.isoformat(),
        "results": result
    }
    filename = "tiger_report_" + stamp.strftime("%Y%m%d_%H%M%S") + ".json"
    path = os.path.join(REPORT_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    return jsonify({"ok": True, "download": "/reports/" + filename})

@app.get("/reports/<path:filename>")
def download_report(filename):
    return send_from_directory(REPORT_DIR, filename, as_attachment=True)

if __name__ == "__main__":
    # Local development only. Put behind a production WSGI server when deployed.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "10000")), debug=False)
